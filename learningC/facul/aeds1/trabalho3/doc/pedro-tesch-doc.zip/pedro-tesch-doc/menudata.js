var menudata={children:[
{text:"Página Principal",url:"index.html"},
{text:"Estruturas de Dados",url:"annotated.html",children:[
{text:"Estruturas de Dados",url:"annotated.html"},
{text:"Índice das Estruturas de Dados",url:"classes.html"},
{text:"Campos de Dados",url:"functions.html",children:[
{text:"Todos",url:"functions.html"},
{text:"Variáveis",url:"functions_vars.html"}]}]},
{text:"Arquivos",url:"files.html",children:[
{text:"Lista de Arquivos",url:"files.html"},
{text:"Globais",url:"globals.html",children:[
{text:"Todos",url:"globals.html"},
{text:"Funções",url:"globals_func.html"},
{text:"Definições de Tipos",url:"globals_type.html"},
{text:"Definições e Macros",url:"globals_defs.html"}]}]}]}
