var searchData=
[
  ['nome_5fdo_5farquivo',['nome_do_arquivo',['../struct____arquivo.html#a48575feaacb4d1f07326890dc8950b8f',1,'__arquivo']]],
  ['num_5fblocos',['num_blocos',['../struct____arquivo.html#a4cf434446339f85829bee468bfee4365',1,'__arquivo']]]
];
