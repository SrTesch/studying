var searchData=
[
  ['imprimir_5farq',['imprimir_arq',['../functions_8c.html#a1d3b6b3bbbea9bf5ea9a20b9c75bd2df',1,'imprimir_arq(arquivo **lista_arq, no **lista):&#160;functions.c'],['../functions_8h.html#a1d3b6b3bbbea9bf5ea9a20b9c75bd2df',1,'imprimir_arq(arquivo **lista_arq, no **lista):&#160;functions.c']]],
  ['imprimir_5flista',['imprimir_lista',['../functions_8c.html#a11c6efd902f812e836d529621293eda2',1,'imprimir_lista(arquivo **lista_arq, no **lista):&#160;functions.c'],['../functions_8h.html#a11c6efd902f812e836d529621293eda2',1,'imprimir_lista(arquivo **lista_arq, no **lista):&#160;functions.c']]],
  ['inserir',['inserir',['../functions_8c.html#a1d17d1c597a6d313a02c301f0fdec603',1,'inserir(int inicio, char *text, no **lista):&#160;functions.c'],['../functions_8h.html#a1d17d1c597a6d313a02c301f0fdec603',1,'inserir(int inicio, char *text, no **lista):&#160;functions.c']]]
];
