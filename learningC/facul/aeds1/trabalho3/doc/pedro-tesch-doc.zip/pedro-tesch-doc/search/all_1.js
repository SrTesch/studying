var searchData=
[
  ['arquivo',['arquivo',['../structs_8h.html#af6f6ee2a3594500b5a02c5bb29b96aa0',1,'structs.h']]]
];
