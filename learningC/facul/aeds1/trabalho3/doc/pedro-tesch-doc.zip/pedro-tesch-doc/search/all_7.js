var searchData=
[
  ['ler_5farq',['ler_arq',['../functions_8c.html#abd6295720db7444ddf2e4e02cc095ff1',1,'ler_arq(no **lista, int espacos_livres, arquivo **lista_arq):&#160;functions.c'],['../functions_8h.html#abd6295720db7444ddf2e4e02cc095ff1',1,'ler_arq(no **lista, int espacos_livres, arquivo **lista_arq):&#160;functions.c']]]
];
