var searchData=
[
  ['no',['no',['../structs_8h.html#aba8be02b0d256c6257b8d6471e1c701d',1,'structs.h']]],
  ['nome_5fdo_5farquivo',['nome_do_arquivo',['../struct____arquivo.html#a48575feaacb4d1f07326890dc8950b8f',1,'__arquivo']]],
  ['num_5fblocos',['num_blocos',['../struct____arquivo.html#a4cf434446339f85829bee468bfee4365',1,'__arquivo']]]
];
