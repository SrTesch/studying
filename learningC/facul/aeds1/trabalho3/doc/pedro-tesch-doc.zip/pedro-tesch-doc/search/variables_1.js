var searchData=
[
  ['inicio',['inicio',['../struct____arquivo.html#a73f53b0349bb995757a60c9c0bde3569',1,'__arquivo']]]
];
