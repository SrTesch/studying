var searchData=
[
  ['_5f_5farquivo',['__arquivo',['../struct____arquivo.html',1,'']]],
  ['_5f_5fno_5fgeral',['__no_geral',['../struct____no__geral.html',1,'']]]
];
