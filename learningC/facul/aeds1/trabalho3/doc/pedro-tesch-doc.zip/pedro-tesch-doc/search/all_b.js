var searchData=
[
  ['remover_5farq',['remover_arq',['../functions_8c.html#aac1fa0ca18be3101ca193bf2be16588a',1,'remover_arq(arquivo **lista_arq, no **lista):&#160;functions.c'],['../functions_8h.html#aac1fa0ca18be3101ca193bf2be16588a',1,'remover_arq(arquivo **lista_arq, no **lista):&#160;functions.c']]]
];
