var searchData=
[
  ['buscar_5ftermo',['buscar_termo',['../functions_8c.html#ad7e3a87c5713737a0780b5973d035f9a',1,'buscar_termo(arquivo **lista_arq, no **lista):&#160;functions.c'],['../functions_8h.html#ad7e3a87c5713737a0780b5973d035f9a',1,'buscar_termo(arquivo **lista_arq, no **lista):&#160;functions.c']]]
];
