var indexSectionsWithContent =
{
  0: "_abcefilmnprs",
  1: "_",
  2: "fs",
  3: "bceilr",
  4: "cinp",
  5: "an",
  6: "_m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Estruturas de Dados",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de Tipos",
  6: "Definições e Macros"
};

