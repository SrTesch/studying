var searchData=
[
  ['end_5farq',['end_arq',['../functions_8c.html#a7249c6b6faf4dbf90700a73e4712ed81',1,'end_arq(arquivo **lista_arq, char *arq):&#160;functions.c'],['../functions_8h.html#a7249c6b6faf4dbf90700a73e4712ed81',1,'end_arq(arquivo **lista_arq, char *arq):&#160;functions.c']]],
  ['entervoltar',['enterVoltar',['../functions_8c.html#ac70386beb7fbf8073d7a8bad6658956c',1,'enterVoltar():&#160;functions.c'],['../functions_8h.html#ac70386beb7fbf8073d7a8bad6658956c',1,'enterVoltar():&#160;functions.c']]],
  ['existe',['existe',['../functions_8c.html#a7bad7fe395e82c34ff86ed2b49534dd6',1,'existe(char *str1, char *str2, int indice):&#160;functions.c'],['../functions_8h.html#a7bad7fe395e82c34ff86ed2b49534dd6',1,'existe(char *str1, char *str2, int indice):&#160;functions.c']]]
];
